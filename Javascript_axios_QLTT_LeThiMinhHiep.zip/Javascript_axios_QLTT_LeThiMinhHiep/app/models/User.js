function User(tk,ten,pass,mail,type,nn,desc,hinh){
    this.taiKhoan = tk;
    this.hoTen = ten;
    this.matKhau = pass;
    this.email = mail;
    this.loaiND = type;
    this.ngonNgu = nn;
    this.moTa = desc;
    this.hinhAnh = hinh;
}